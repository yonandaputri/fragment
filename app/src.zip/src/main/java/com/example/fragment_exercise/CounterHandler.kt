package com.example.fragment_exercise

interface CounterHandler{
    fun increment()
    fun decrement()
}